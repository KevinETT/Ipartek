package com.ipartek;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S003TiendaRopaApplicationTests {

	@Test
	void contextLoads() {
	}

}
