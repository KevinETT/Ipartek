package com.ipartek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S003TiendaRopaApplication {

	public static void main(String[] args) {
		SpringApplication.run(S003TiendaRopaApplication.class, args);
	}

}
