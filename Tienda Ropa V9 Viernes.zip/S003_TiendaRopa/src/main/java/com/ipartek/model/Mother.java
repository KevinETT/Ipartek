package com.ipartek.model;

public class Mother {
	

}
