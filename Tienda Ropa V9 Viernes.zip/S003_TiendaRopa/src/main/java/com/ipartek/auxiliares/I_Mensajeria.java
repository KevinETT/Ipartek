package com.ipartek.auxiliares;

public interface I_Mensajeria {

	//codigo 1
	String MSG_PROD_ANYADIDO="Producto añadido";
	
	//codigo 2
	String MSG_IMG_PROD_BORRADO="Imagen de producto borrada";
	
	//codigo 3
	String MSG_PROD_BORRADO="Producto borrado";
	
	//codigo 4
	String MSG_PROD_MODIFICADO="Producto modificado";
	
	//codigo 5
	String MSG_LOGIN_ACCESO_DENEGADO="El usuario y la contraseña no coinciden";
	
	
}
